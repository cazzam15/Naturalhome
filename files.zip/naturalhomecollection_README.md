# The Natural Home Collection — Brand Site

A standalone, two-file website for the brand. Built with hand-written HTML, CSS, and a touch of JavaScript — no build step, no dependencies, no framework.

## Files

- **`index.html`** — the main website homepage (~57 KB)
- **`Natural_Home_Recommended_Products.pdf`** — the free downloadable companion guide (~170 KB)
- **`recipes/`** — folder containing six recipe pages and a shared stylesheet:
  - `recipes/index.html` — the recipes hub page
  - `recipes/style.css` — shared brand stylesheet for all recipe pages
  - `recipes/green-clean-all-purpose-spray.html`
  - `recipes/natural-beauty-lip-balm.html`
  - `recipes/zero-waste-carrot-top-pesto.html`
  - `recipes/herbal-elderberry-syrup.html`
  - `recipes/pet-care-paw-balm.html`

The folder structure must be preserved when uploaded — the recipes folder needs to live alongside `index.html`.

## What's inside the site

- **Hero** with botanical illustration and animated entrance
- **Story** section with author bio and signature
- **The Books** — all 5 volumes plus the bundle, each with its own SVG cover
- **Philosophy** — four brand principles on a dark surface
- **Free Companion Guide** — section with one-click PDF download
- **Free Recipes** — five SEO-optimised recipe pages (one per book) with structured data for Google rich results, each linking back to the relevant book on Amazon
- **Testimonial** quote
- **Shop CTA** linking through to Amazon with the `cazza09-21` affiliate tag
- **Footer** with full sitemap and credits

The aesthetic is editorial-magazine: Cormorant Garamond display serif paired with Inter Tight sans, a warm paper palette with rust accents, generous whitespace, hand-drawn signature touches, and subtle paper-grain texture overlay.

## How to deploy

The site needs both files together — `index.html` and `Natural_Home_Recommended_Products.pdf` — in the same folder. Several easy ways to put it online:

### Option 1 — Netlify Drop (easiest)
1. Put `index.html` and `Natural_Home_Recommended_Products.pdf` together in a folder
2. Go to https://app.netlify.com/drop
3. Drag the entire folder onto the page
4. You get a live URL in seconds (e.g. `something-random.netlify.app`)
5. In Netlify settings you can connect a custom domain

### Option 2 — GitHub Pages (free, permanent)
1. Create a repo at https://github.com (e.g. `natural-home-collection`)
2. Upload **both files** (HTML and PDF)
3. Repo Settings → Pages → set source to `main` branch root
4. Live at `username.github.io/natural-home-collection`

### Option 3 — Cloudflare Pages
1. Go to https://pages.cloudflare.com
2. Connect to GitHub repo or upload directly (both files)
3. Free SSL, custom domains, fast global CDN

### Option 4 — Buy a domain and host anywhere
Recommended domains to consider:
- `naturalhomecollection.co.uk` (~£8/yr at Namecheap)
- `cmorrisonbooks.co.uk`
- `thenaturalhome.co.uk`

Once you have a domain, point it at whichever host above you used.

## Customisation

Everything is in one file — `index.html`. Common edits:

- **Update the Amazon link**: search for `https://www.amazon.co.uk/s?k=C+Morrison` and replace with your actual book URLs once published
- **Add real Instagram link**: find `<a href="#">Instagram</a>` in the footer
- **Change author bio**: search for "The Natural Home Collection began" and edit the story
- **Update colours**: see the `:root` CSS variables at the top — change `--rust`, `--sage`, etc. to retheme the whole site

## Browser support

Works in all modern browsers (Chrome, Safari, Firefox, Edge from 2020 onwards). Mobile-responsive at every breakpoint.

## Performance

- ~44 KB single file (loads instantly even on slow connections)
- Two Google Fonts (Cormorant Garamond, Inter Tight, Caveat)
- Zero JavaScript dependencies
- All illustrations are inline SVG (no image files to host)
